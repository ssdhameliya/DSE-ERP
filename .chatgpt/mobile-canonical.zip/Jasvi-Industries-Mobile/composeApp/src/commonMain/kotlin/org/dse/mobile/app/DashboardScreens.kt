@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
package org.dse.mobile.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.dse.mobile.core.api.*
import org.dse.mobile.core.model.*
import org.dse.mobile.core.offline.OfflineRepository
import org.dse.mobile.core.offline.platformOfflineNowMillis

@Composable
internal fun DashboardScreen(
    api:DseErpHttpClient,
    p:PermissionContext,
    onTab:(MainTab)->Unit,
    onMore:(MoreDestination)->Unit,
    onSearch:()->Unit={},
    onTarget:(RecordTarget)->Unit={},
){
    var data by remember{mutableStateOf<InsightDashboardBundle?>(null)}
    var msg by remember{mutableStateOf("Loading live workspace…")}
    var key by remember{mutableIntStateOf(0)}
    LaunchedEffect(api,key){
        when(val r=api.insightDashboard("This Month")){
            is ApiResult.Success->{
                data=r.value
                msg=if(r.source==ApiDataSource.CACHE)"Offline snapshot • ${r.cachedAtMillis?.let(::cacheAgeDash).orEmpty()}" else "Live UAT • updated now"
                if(r.source==ApiDataSource.LIVE&&OfflineRepository.widgetSharingEnabled()){
                    val today=(api.insightDashboard("Today") as? ApiResult.Success)?.value?.snapshot
                    if(today!=null)platformPublishWidgetSnapshot(
                        WidgetDashboardSnapshot(
                            salesToday=today.salesValue,
                            receivables=r.value.snapshot.receivables,
                            purchases=today.purchaseValue,
                            payables=r.value.snapshot.payables,
                            bankBalance=r.value.snapshot.cash,
                            updatedAtMillis=platformOfflineNowMillis(),
                        )
                    )
                }
            }
            else->msg=r.readableMessage()
        }
    }
    val s=data?.snapshot
    val name=p.user?.fullName?.takeIf{!it.isNullOrBlank()}?:p.user?.username.orEmpty()
    val firstName=name.substringBefore(' ').ifBlank{"there"}

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState()).padding(horizontal=14.dp,vertical=10.dp),
        verticalArrangement=Arrangement.spacedBy(13.dp),
    ){
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
            Column(Modifier.weight(1f)){
                Text("Welcome back,",style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
                Text("$firstName!",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.ExtraBold)
            }
            UatStatusPill(true)
            Spacer(Modifier.width(7.dp))
            FilledTonalIconButton(onClick={key++},shape=androidx.compose.foundation.shape.RoundedCornerShape(15.dp)){Icon(Icons.Rounded.Refresh,"Refresh")}
        }

        Surface(
            modifier=Modifier.fillMaxWidth().clickable(onClick=onSearch),
            shape=androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
            color=MaterialTheme.colorScheme.surface,
            border=androidx.compose.foundation.BorderStroke(1.dp,MaterialTheme.colorScheme.primary.copy(.12f)),
            shadowElevation=4.dp,
        ){
            Row(Modifier.padding(horizontal=14.dp,vertical=12.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)){
                Icon(Icons.Rounded.Search,null,tint=MaterialTheme.colorScheme.primary)
                Text("Search invoices, customers, items…",Modifier.weight(1f),style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
                PremiumIconTile(Icons.Rounded.QrCodeScanner,MaterialTheme.colorScheme.primary,size=34.dp)
            }
        }

        DseHeroKpi(
            label="Active Sales",
            value=money(s?.salesValue),
            supporting="${s?.invoices?:0} sales document(s) • This Month",
            icon=Icons.Rounded.BarChart,
        )

        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){
            DseMetricTile("Purchases",compactMoney(s?.purchaseValue),Icons.Rounded.ShoppingBag,Modifier.weight(1f),DseWarning)
            DseMetricTile("Receivables",compactMoney(s?.receivables),Icons.Rounded.CreditCard,Modifier.weight(1f),DseInfo)
            DseMetricTile("Payables",compactMoney(s?.payables),Icons.Rounded.Receipt,Modifier.weight(1f),DsePurple)
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){
            DseMetricTile("Cash",compactMoney(s?.cash),Icons.Rounded.AccountBalanceWallet,Modifier.weight(1f),DseSuccess)
            DseMetricTile("Low Stock",(s?.lowStock?:0).toString(),Icons.Rounded.Inventory2,Modifier.weight(1f),if((s?.lowStock?:0)>0)DseWarning else DseSuccess)
            DseMetricTile("Customers",(s?.customers?:0).toString(),Icons.Rounded.Groups,Modifier.weight(1f),DseInfo)
        }

        PremiumSectionHeader("Quick Actions","View more"){onMore(MoreDestination.MASTERS)}
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){
            if(p.can("SALES","CREATE"))QuickActionTile("New Sale",Icons.Rounded.AddShoppingCart,DsePurple,Modifier.weight(1f)){onTarget(RecordTarget("SALES","__CREATE__"))}
            if(p.can("PURCHASE","CREATE"))QuickActionTile("Purchase",Icons.Rounded.ShoppingBag,DseWarning,Modifier.weight(1f)){onTarget(RecordTarget("PURCHASE","__CREATE__"))}
            if(p.can("QUOTATION","CREATE"))QuickActionTile("Quotation",Icons.Rounded.RequestQuote,DseInfo,Modifier.weight(1f)){onTarget(RecordTarget("QUOTATION","__CREATE__"))}
            if(p.can("CUSTOMERS","CREATE"))QuickActionTile("Customer",Icons.Rounded.PersonAdd,DseSuccess,Modifier.weight(1f)){onTarget(RecordTarget("CUSTOMER","__CREATE__"))}
        }

        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){
            PremiumCard(Modifier.weight(1f),padding=13.dp){
                Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)){PremiumIconTile(Icons.Rounded.AccountBalanceWallet,DseDanger,size=36.dp);Text("Receivables",style=MaterialTheme.typography.labelLarge)}
                Text(compactMoney(s?.receivables),style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.ExtraBold)
                Text("${s?.openReceivables?:0} open",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                TextButton(onClick={onTab(MainTab.SALES)},contentPadding=PaddingValues(0.dp)){Text("View register");Spacer(Modifier.width(3.dp));Icon(Icons.Rounded.ArrowForward,null,Modifier.size(15.dp))}
            }
            PremiumCard(Modifier.weight(1f),padding=13.dp){
                Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)){PremiumIconTile(Icons.Rounded.NotificationsActive,DsePurple,size=36.dp);Text("Reminders",style=MaterialTheme.typography.labelLarge)}
                Text((data?.activities?.size?:0).toString(),style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.ExtraBold)
                Text("Stay on top of follow-ups",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                TextButton(onClick={onMore(MoreDestination.REMINDERS)},contentPadding=PaddingValues(0.dp)){Text("Open center");Spacer(Modifier.width(3.dp));Icon(Icons.Rounded.ArrowForward,null,Modifier.size(15.dp))}
            }
        }

        data?.recent?.take(6)?.takeIf{it.isNotEmpty()}?.let{rows->
            PremiumSectionHeader("Recent Documents")
            rows.forEach{r->
                Surface(
                    shape=androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
                    color=MaterialTheme.colorScheme.surface,
                    border=androidx.compose.foundation.BorderStroke(1.dp,MaterialTheme.colorScheme.outline.copy(.34f)),
                    shadowElevation=2.dp,
                    modifier=Modifier.fillMaxWidth().clickable{onTarget(RecordTarget(r.type,r.number))}
                ){
                    Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)){
                        PremiumIconTile(Icons.Rounded.Description,MaterialTheme.colorScheme.primary,size=42.dp)
                        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(2.dp)){Text(r.number,fontWeight=FontWeight.Bold);Text("${r.type} • ${r.party}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Text(r.date,style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}
                        Text(money(r.amount),style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.ExtraBold)
                        Icon(Icons.Rounded.ChevronRight,"Open",tint=MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }

        data?.topCustomers?.take(5)?.takeIf{it.isNotEmpty()}?.let{rows->
            DseSection("Top Customers",Icons.Rounded.Groups){rows.forEachIndexed{i,r->Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(9.dp)){Surface(shape=androidx.compose.foundation.shape.CircleShape,color=MaterialTheme.colorScheme.primaryContainer){Text("${i+1}",Modifier.padding(horizontal=9.dp,vertical=6.dp),color=MaterialTheme.colorScheme.primary,fontWeight=FontWeight.Bold)};Text(r,Modifier.weight(1f))}}}
        }
        Text(msg,style=MaterialTheme.typography.labelSmall,color=if(msg.startsWith("Offline"))DseWarning else MaterialTheme.colorScheme.onSurfaceVariant,modifier=Modifier.align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun QuickActionTile(label:String,icon:androidx.compose.ui.graphics.vector.ImageVector,accent:androidx.compose.ui.graphics.Color,modifier:Modifier=Modifier,onClick:()->Unit){
    Surface(
        modifier=modifier.clickable(onClick=onClick),
        shape=androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
        color=MaterialTheme.colorScheme.surface,
        border=androidx.compose.foundation.BorderStroke(1.dp,accent.copy(.13f)),
        shadowElevation=2.dp,
    ){
        Column(Modifier.padding(horizontal=8.dp,vertical=12.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(7.dp)){
            PremiumIconTile(icon,accent,size=40.dp)
            Text(label,style=MaterialTheme.typography.labelSmall,fontWeight=FontWeight.SemiBold,maxLines=1)
        }
    }
}


@Composable internal fun GlobalSearchDialog(api:DseErpHttpClient,onClose:()->Unit,onOpen:(GlobalSearchRow)->Unit={}){
    var q by remember{mutableStateOf("")}
    var rows by remember{mutableStateOf<List<GlobalSearchRow>>(emptyList())}
    var msg by remember{mutableStateOf("Search invoices, parties, items, payments, returns and bank records")}
    var busy by remember{mutableStateOf(false)}
    val scope=rememberCoroutineScope()
    suspend fun searchNow(term:String=q){
        val value=term.trim()
        if(value.length<2){rows=emptyList();msg="Type at least 2 characters";return}
        busy=true
        when(val r=api.globalSearch(value)){
            is ApiResult.Success->{rows=r.value;msg="${rows.size} result(s)"}
            else->{rows=emptyList();msg=r.readableMessage()}
        }
        busy=false
    }
    LaunchedEffect(q){
        val value=q.trim()
        if(value.length<2){rows=emptyList();return@LaunchedEffect}
        delay(300)
        searchNow(value)
    }
    PremiumAlertDialog(
        onDismissRequest=onClose,
        title={Text("Global Search")},
        text={Column(Modifier.fillMaxWidth().heightIn(max=620.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)){
            OutlinedTextField(
                q,{q=it},label={Text("Search Jasvi Industries")},modifier=Modifier.fillMaxWidth(),singleLine=true,shape=MaterialTheme.shapes.medium,
                leadingIcon={Icon(Icons.Rounded.Search,null)},
                trailingIcon={if(busy)Icon(Icons.Rounded.Sync,"Searching") else if(q.isNotBlank())IconButton(onClick={q="";rows=emptyList();msg="Search invoices, parties, items, payments, returns and bank records"}){Icon(Icons.Rounded.Clear,"Clear")}},
                keyboardOptions=KeyboardOptions(imeAction=ImeAction.Search),
                keyboardActions=KeyboardActions(onSearch={scope.launch{searchNow()}}),
            )
            Text(msg,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
            if(busy)LinearProgressIndicator(Modifier.fillMaxWidth())
            if(!busy&&q.trim().length>=2&&rows.isEmpty()){
                Surface(shape=androidx.compose.foundation.shape.RoundedCornerShape(18.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(.35f),modifier=Modifier.fillMaxWidth()){
                    Row(Modifier.padding(14.dp),horizontalArrangement=Arrangement.spacedBy(10.dp),verticalAlignment=Alignment.CenterVertically){
                        Icon(Icons.Rounded.SearchOff,null,tint=MaterialTheme.colorScheme.primary)
                        Column{Text("No matching ERP records",fontWeight=FontWeight.Bold);Text("Try invoice number, party, item, payment reference or bank narration.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}
                    }
                }
            }
            rows.take(100).groupBy{it.module.ifBlank{it.moduleKey}}.forEach{(module,moduleRows)->
                Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    PremiumIconTile(semanticActionIcon(module),MaterialTheme.colorScheme.primary,size=34.dp)
                    Text(module.ifBlank{"ERP Records"},style=MaterialTheme.typography.titleSmall,fontWeight=FontWeight.ExtraBold,modifier=Modifier.weight(1f))
                    Text("${moduleRows.size}",style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.primary,fontWeight=FontWeight.Bold)
                }
                moduleRows.forEach{r->
                    DseRecordCard(
                        title=r.reference.ifBlank{r.description},
                        subtitle=r.description.ifBlank{r.module},
                        amount="",
                        statuses=listOf("Module" to r.module),
                        meta=r.detail,
                        swipeStartActions=listOf(SwipeAction("View",Icons.Rounded.Visibility){onOpen(r)}),
                    ){onOpen(r)}
                    PremiumSecondaryButton("View ${r.reference.ifBlank{r.description}}",{onOpen(r)},Modifier.fillMaxWidth(),icon=Icons.Rounded.Visibility)
                }
            }
            Spacer(Modifier.height(8.dp))
        }},
        confirmButton={TextButton(onClick=onClose){Text("Close")}},
    )
}

private fun cacheAgeDash(last:Long):String{val m=((platformOfflineNowMillis()-last).coerceAtLeast(0)/60_000);return when{m<1->"just now";m<60->"$m min ago";m<1440->"${m/60} hr ago";else->"${m/1440} day(s) ago"}}
